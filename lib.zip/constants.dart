import 'package:flutter/material.dart';

const kBlueIcon = Color(0xff0bbbfe);
const kRedFont = Color(0xfff45e7a);
const kGreyFont = Color(0xffb7adac);
const kL1 = Color(0xffed6f9f);
const kL12 = Color(0xffec8c6a);
const kL2 = Color(0xff5471ec);
const kL22 = Color(0xff0bbbfe);
const kL3 = Color(0xffa28dd0);
const kL32 = Color(0xfff4bee7);
const kBlueBg = Color(0xff3293f4);
const kG1 = Color(0xffb5bd05);

const kFontFamily = 'Sf-Pro-Text';
