class QuestionMultiple {
  String questionText;
  int questionAnswer;
  List<String> options;

  QuestionMultiple(
    this.questionText,
    this.questionAnswer,
    this.options,
  );
}
